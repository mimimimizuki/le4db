import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class LoginCheckServlet extends HttpServlet {

	private String _hostname = null;
	private String _dbname = null;
	private String _username = null;
	private String _password = null;

	public void init() throws ServletException {
		// iniファイルから自分のデータベース情報を読み込む
		String iniFilePath = getServletConfig().getServletContext().getRealPath("WEB-INF/le4db.ini");
		try {
			FileInputStream fis = new FileInputStream(iniFilePath);
			Properties prop = new Properties();
			prop.load(fis);
			_hostname = prop.getProperty("hostname");
			_dbname = prop.getProperty("dbname");
			_username = prop.getProperty("username");
			_password = prop.getProperty("password");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String username = request.getParameter("username"); // username
		String password = request.getParameter("password"); // pass
		out.println("<html>");
		out.println("<style> body {color : dimgray;  font : 20px;}</style>");
		out.println("<body>");

		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection("jdbc:postgresql://" + _hostname + ":5432/" + _dbname, _username,
					_password);
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT * FROM login WHERE username = '" + username + "'");
			while (rs.next()) {
				String pass = rs.getString("password");
				if (pass.contains(password)) {
					out.print("<h2>ログインに成功しました。</h2>");
					if (username.contains("donor")) {
						int user_id = rs.getInt("user_id");
						out.print("<p>あなたのユーザIDは、<a href=\"donor.html?user_id=" + user_id + "\">" + user_id
								+ "</a>です</p>");
					} else if (username.contains("patient")) {
						int user_id = rs.getInt("user_id");
						out.print("<p>あなたのユーザIDは、<a href=\"patient.html?user_id=" + user_id + "\">" + user_id
								+ "</a>です</p>");
					} else {
						out.print("<a href=\"cordinator.html\">管理ページへ</a>");
					}
				} else {
					out.println("ログイン失敗です。");
					out.print("<a href=\"login.html\">ログインページへ戻る</a>");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		out.println("<br/>");

		out.println("</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void destroy() {
	}

}
